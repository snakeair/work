var s="./assets/img-12-b4689112.png";export{s as _};
